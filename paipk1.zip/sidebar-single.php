<?php
/**
 * @package WordPress
 * @subpackage paipk1
 * @since paipk1 1.0
 */

dynamic_sidebar('SingleSidebar'); ?>