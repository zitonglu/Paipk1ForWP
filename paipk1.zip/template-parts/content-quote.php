<?php
/**
 * this is content style,for single.php
 *
 * @package WordPress
 * @subpackage paipk1
 * @since paipk1 1.0
 */
?>
<?php include (TEMPLATEPATH . '/template-parts/content-aside.php'); ?>