<?php
/**
 *
 * @since paipk1 1.0
 * 
 * @return Code
 */
echo get_option('paipk1_baiduShare');
?>